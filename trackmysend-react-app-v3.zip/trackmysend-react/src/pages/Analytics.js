import React, { useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend
);

function Analytics({ transactions, budget, t }) {
  const expenses = transactions.filter(tx => tx.type === 'expense');

  // Category totals
  const categoryTotals = {};
  expenses.forEach(tx => {
    categoryTotals[tx.category] = (categoryTotals[tx.category] || 0) + tx.amount;
  });
  const labels = Object.keys(categoryTotals);
  const values = Object.values(categoryTotals);
  const totalSpent = budget.spent || 1;

  // Timeline data
  const timelineData = {};
  expenses.forEach(tx => {
    const date = tx.date.split('T')[0];
    timelineData[date] = (timelineData[date] || 0) + tx.amount;
  });
  const timelineDates = Object.keys(timelineData).sort();
  const timelineValues = timelineDates.map(d => timelineData[d]);

  const chartColors = {
    backgroundColor: 'rgba(229, 9, 20, 0.8)',
    borderColor: '#e50914',
  };

  const axisStyle = {
    ticks: { color: '#b3b3b3' },
    grid: { color: '#333333' },
  };

  const barData = {
    labels,
    datasets: [{
      label: t.analytics.expensesByCategory,
      data: values,
      backgroundColor: chartColors.backgroundColor,
      borderRadius: 6,
      borderSkipped: false,
    }],
  };

  const barOptions = {
    responsive: true,
    maintainAspectRatio: true,
    scales: {
      x: axisStyle,
      y: {
        ...axisStyle,
        beginAtZero: true,
        ticks: {
          ...axisStyle.ticks,
          callback: val => `₹${val}`,
        },
      },
    },
    plugins: {
      legend: { labels: { color: '#b3b3b3' } },
      tooltip: { callbacks: { label: ctx => `₹${ctx.parsed.y.toFixed(2)}` } },
    },
  };

  const lineData = {
    labels: timelineDates,
    datasets: [{
      label: 'Daily Expenses',
      data: timelineValues,
      borderColor: chartColors.borderColor,
      backgroundColor: 'rgba(229, 9, 20, 0.1)',
      tension: 0.3,
      fill: true,
    }],
  };

  const lineOptions = {
    responsive: true,
    maintainAspectRatio: true,
    scales: {
      x: axisStyle,
      y: {
        ...axisStyle,
        beginAtZero: true,
        ticks: {
          ...axisStyle.ticks,
          callback: val => `₹${val}`,
        },
      },
    },
    plugins: {
      legend: { labels: { color: '#b3b3b3' } },
      tooltip: { callbacks: { label: ctx => `₹${ctx.parsed.y.toFixed(2)}` } },
    },
  };

  if (expenses.length === 0) {
    return (
      <div>
        <div className="page-title">
          <i className="fas fa-chart-line" style={{ color: 'var(--primary-color)', marginRight: 10 }} />
          {t.analytics.analyticsHeader}
        </div>
        <div className="empty-state" style={{ padding: 60 }}>
          <i className="fas fa-chart-bar" />
          <p>{t.analytics.noData}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="page-title">
        <i className="fas fa-chart-line" style={{ color: 'var(--primary-color)', marginRight: 10 }} />
        {t.analytics.analyticsHeader}
      </div>

      <div className="analytics-container">
        <div className="chart-container">
          <h3>{t.analytics.expensesByCategory}</h3>
          <Bar data={barData} options={barOptions} />
        </div>

        <div className="category-list">
          <h3>{t.analytics.expenseBreakdown}</h3>
          {labels.map((cat, idx) => {
            const percent = ((values[idx] / totalSpent) * 100).toFixed(1);
            return (
              <div key={cat} className="category-item">
                <div className="category-item-header">
                  <span style={{ textTransform: 'capitalize', fontWeight: 500 }}>{cat}</span>
                  <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
                    ₹{values[idx].toFixed(2)} ({percent}%)
                  </span>
                </div>
                <div className="category-bar">
                  <div className="category-bar-fill" style={{ width: `${percent}%` }} />
                </div>
              </div>
            );
          })}
        </div>

        <div className="expense-timeline">
          <h3>{t.analytics.expenseTimeline}</h3>
          <Line data={lineData} options={lineOptions} />
        </div>
      </div>
    </div>
  );
}

export default Analytics;
