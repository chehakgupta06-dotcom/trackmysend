import React, { useState } from 'react';

const faqs = [
  {
    category: 'General Guides',
    icon: 'fa-book-open',
    items: [
      {
        q: 'How do I get started with TrackMySpend?',
        a: 'Start by going to the Budget page and setting your monthly budget. Then head to Transactions to log your expenses and income. Visit Analytics to see your spending breakdown.'
      },
      {
        q: 'How do I protect my data?',
        a: 'All your data is stored locally in your browser\'s localStorage. It never leaves your device unless you choose to export it. Clear browser data to remove everything.'
      },
      {
        q: 'What is the Summary/Dashboard page?',
        a: 'The Dashboard gives you a quick overview: total budget, amount spent, remaining balance, savings, and a visual progress bar showing how much of your budget you\'ve used.'
      },
      {
        q: 'How do I contact support?',
        a: 'Use the "Leave Feedback" button at the bottom of any page to send us a message. You can also reach us via the About Us page.'
      },
    ]
  },
  {
    category: 'User Account & Data',
    icon: 'fa-user-shield',
    items: [
      {
        q: 'Is my financial data private?',
        a: 'Yes. TrackMySpend stores all data locally in your browser using localStorage. No account is required and no data is sent to any server (except optional feedback emails).'
      },
      {
        q: 'Can I sync data between devices?',
        a: 'Currently, data is stored per-browser/device. To transfer data, you can manually export your transactions or use the same browser profile across devices.'
      },
      {
        q: 'What happens if I clear my browser data?',
        a: 'Clearing browser data will erase all your saved budgets, transactions, and bills. We recommend noting important data before clearing. A cloud sync feature is planned for a future update.'
      },
    ]
  },
  {
    category: 'Transactions & Budget',
    icon: 'fa-exchange-alt',
    items: [
      {
        q: 'How do I add a transaction using voice?',
        a: 'Click the red microphone button on the Transactions page and say something like: "add expense 500 for food" or "add income 2000 for salary". Make sure to allow microphone access when prompted.'
      },
      {
        q: 'What categories are available?',
        a: 'You can categorize transactions as: Food & Dining, Transportation, Entertainment, Utilities, Shopping, or Other.'
      },
      {
        q: 'How do pending bills work?',
        a: 'Add your upcoming bills with a due date. TrackMySpend will show how many days remain and alert you when a bill is due tomorrow. Clicking "Mark as Paid" will automatically log it as an expense.'
      },
      {
        q: 'Can I set a weekly or yearly budget?',
        a: 'Yes! On the Budget page, select your preferred period: Monthly, Weekly, or Yearly. Set start and end dates accordingly.'
      },
    ]
  },
  {
    category: 'Analytics & Charts',
    icon: 'fa-chart-line',
    items: [
      {
        q: 'What charts are available in Analytics?',
        a: 'The Analytics page shows a Bar Chart of expenses by category and a Line Chart (Expense Timeline) showing your daily spending over time.'
      },
      {
        q: 'Why are my charts empty?',
        a: 'Charts only appear once you have added at least one expense transaction. Add a transaction in the Transactions tab and the charts will populate automatically.'
      },
    ]
  },
  {
    category: 'Voice & Language',
    icon: 'fa-microphone',
    items: [
      {
        q: 'Which browsers support voice input?',
        a: 'Voice input works best in Google Chrome and Microsoft Edge. Firefox and Safari have limited or no support for the Web Speech API used by TrackMySpend.'
      },
      {
        q: 'What languages are supported in the app?',
        a: 'The UI can be displayed in English, Hindi (हिन्दी), Tamil (தமிழ்), and Japanese (日本語). Use the Language selector in the top navigation bar to switch.'
      },
    ]
  },
];

function FAQItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      style={{
        borderBottom: '1px solid var(--border-color)',
        padding: '14px 0',
        cursor: 'pointer',
      }}
      onClick={() => setOpen(o => !o)}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
        <span style={{ fontWeight: 500, fontSize: 15, color: 'var(--text-color)' }}>{q}</span>
        <i
          className={`fas fa-chevron-${open ? 'up' : 'down'}`}
          style={{ color: 'var(--primary-color)', flexShrink: 0, transition: 'transform 0.2s' }}
        />
      </div>
      {open && (
        <p style={{ marginTop: 10, fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
          {a}
        </p>
      )}
    </div>
  );
}

function FAQ() {
  return (
    <div>
      <div className="page-title">
        <i className="fas fa-question-circle" style={{ color: 'var(--primary-color)', marginRight: 10 }} />
        Frequently Asked Questions
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {faqs.map(section => (
          <div key={section.category} className="card" style={{ padding: 24 }}>
            <h3 style={{
              fontSize: 17,
              fontWeight: 700,
              color: 'var(--primary-color)',
              marginBottom: 4,
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}>
              <i className={`fas ${section.icon}`} />
              {section.category}
            </h3>
            {section.items.map(item => (
              <FAQItem key={item.q} q={item.q} a={item.a} />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

export default FAQ;
