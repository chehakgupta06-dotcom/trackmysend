import React, { useState, useRef } from 'react';
import { useAlert } from '../AlertContext';

const CATEGORIES = ['food', 'transportation', 'entertainment', 'utilities', 'shopping', 'other'];

const CATEGORY_ALIASES = {
  food: ['food', 'dining', 'restaurant', 'lunch', 'dinner', 'breakfast', 'eating', 'meal', 'snack', 'groceries', 'grocery'],
  transportation: ['transportation', 'transport', 'travel', 'bus', 'auto', 'cab', 'uber', 'ola', 'petrol', 'fuel', 'metro', 'train', 'taxi'],
  entertainment: ['entertainment', 'movie', 'movies', 'netflix', 'game', 'games', 'fun', 'sport', 'sports', 'concert'],
  utilities: ['utilities', 'utility', 'electricity', 'water', 'bill', 'bills', 'internet', 'phone', 'rent', 'gas'],
  shopping: ['shopping', 'clothes', 'clothing', 'amazon', 'flipkart', 'shop', 'purchase', 'bought'],
  other: ['other', 'misc', 'miscellaneous'],
};

function matchCategory(word) {
  const w = word.toLowerCase();
  for (const [cat, aliases] of Object.entries(CATEGORY_ALIASES)) {
    if (aliases.some(a => w.includes(a) || a.includes(w))) return cat;
  }
  return 'other';
}

function parseVoiceCommand(text) {
  const t = text.toLowerCase().trim();

  // Pattern 1: "add expense 500 for food"
  const p1 = t.match(/add\s+(expense|income|spent|spend)\s+(\d+(?:\.\d+)?)\s+(?:for|on|in)?\s*(.+)/);
  if (p1) {
    const type = (p1[1] === 'income') ? 'income' : 'expense';
    return { type, amount: parseFloat(p1[2]), category: matchCategory(p1[3]), description: `Voice: ${text}` };
  }

  // Pattern 2: "500 rupees for food" / "spent 300 on transport"
  const p2 = t.match(/(\d+(?:\.\d+)?)\s*(?:rupees?|rs\.?|inr)?\s*(?:for|on|in)\s+(.+)/);
  if (p2) {
    return { type: 'expense', amount: parseFloat(p2[1]), category: matchCategory(p2[2]), description: `Voice: ${text}` };
  }

  // Pattern 3: "food 200" / "transport fifty"
  const numberWords = { zero:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90,hundred:100,thousand:1000 };
  let converted = t;
  Object.entries(numberWords).forEach(([w, v]) => { converted = converted.replace(new RegExp(`\\b${w}\\b`, 'g'), String(v)); });
  const p3 = converted.match(/(\w+)\s+(\d+(?:\.\d+)?)/);
  if (p3) {
    const cat = matchCategory(p3[1]);
    if (cat !== 'other' || CATEGORIES.includes(p3[1])) {
      return { type: 'expense', amount: parseFloat(p3[2]), category: cat, description: `Voice: ${text}` };
    }
  }
  const p3b = converted.match(/(\d+(?:\.\d+)?)\s+(\w+)/);
  if (p3b) {
    return { type: 'expense', amount: parseFloat(p3b[1]), category: matchCategory(p3b[2]), description: `Voice: ${text}` };
  }

  return null;
}

function Transactions({ transactions, setTransactions, budget, setBudget, pendingBills, setPendingBills, t }) {
  const { showAlert } = useAlert();
  const [form, setForm] = useState({ type: 'expense', amount: '', category: 'food', description: '' });
  const [billForm, setBillForm] = useState({ name: '', amount: '', dueDate: '' });
  const [isListening, setIsListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const recognitionRef = useRef(null);

  const addTransaction = (overrideForm) => {
    const f = overrideForm || form;
    if (!f.amount || !f.description) { showAlert('warning', 'Please fill in all fields'); return; }
    const amount = parseFloat(f.amount);
    const transaction = { id: Date.now(), type: f.type, amount, category: f.category, description: f.description, date: new Date().toISOString() };

    if (f.type === 'expense') {
      const newSpent = (budget.spent || 0) + amount;
      if (newSpent > budget.amount && budget.amount > 0) showAlert('warning', 'This expense will exceed your budget!');
      setBudget({ ...budget, spent: newSpent });
    }
    setTransactions(prev => [transaction, ...prev]);
    if (!overrideForm) setForm(f2 => ({ ...f2, amount: '', description: '' }));
    showAlert('success', `Transaction added: ₹${amount}`);
  };

  const startVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { showAlert('warning', 'Voice not supported. Use Chrome or Edge.'); return; }

    if (!recognitionRef.current) {
      const rec = new SR();
      rec.continuous = false;
      rec.interimResults = true;
      rec.lang = 'en-IN';
      rec.maxAlternatives = 5;

      rec.onresult = (event) => {
        let finalText = '';
        let interimText = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            // Try all alternatives
            for (let j = 0; j < event.results[i].length; j++) {
              const alt = event.results[i][j].transcript;
              const parsed = parseVoiceCommand(alt);
              if (parsed) {
                finalText = alt;
                setVoiceTranscript(`"${alt}"`);
                setForm({ type: parsed.type, amount: String(parsed.amount), category: parsed.category, description: parsed.description });
                showAlert('success', `Voice: ${parsed.type} ₹${parsed.amount} → ${parsed.category}`);
                setIsListening(false);
                return;
              }
            }
            finalText = event.results[i][0].transcript;
          } else {
            interimText = event.results[i][0].transcript;
          }
        }
        if (interimText) setVoiceTranscript(`Hearing: "${interimText}"`);
        if (finalText && !interimText) {
          setVoiceTranscript(`"${finalText}" — not recognized`);
          showAlert('warning', `Heard "${finalText}". Try: "add expense 500 for food"`);
        }
      };

      rec.onerror = (e) => {
        if (e.error === 'no-speech') showAlert('warning', 'No speech detected. Please speak clearly.');
        else if (e.error === 'not-allowed') showAlert('warning', 'Microphone access denied. Please allow it in browser settings.');
        else showAlert('warning', `Voice error: ${e.error}`);
        setIsListening(false);
        setVoiceTranscript('');
      };
      rec.onend = () => { setIsListening(false); };
      recognitionRef.current = rec;
    }

    setVoiceTranscript('Listening...');
    setIsListening(true);
    try { recognitionRef.current.start(); }
    catch(e) { recognitionRef.current = null; setIsListening(false); }
  };

  const stopVoice = () => {
    if (recognitionRef.current) { recognitionRef.current.stop(); }
    setIsListening(false);
  };

  const addBill = () => {
    if (!billForm.name || !billForm.amount || !billForm.dueDate) { showAlert('warning', 'Please fill in all bill details'); return; }
    setPendingBills(prev => [...prev, { id: Date.now(), name: billForm.name, amount: parseFloat(billForm.amount), dueDate: billForm.dueDate, paid: false }]);
    setBillForm({ name: '', amount: '', dueDate: '' });
    showAlert('success', `Bill "${billForm.name}" added`);
  };

  const markBillAsPaid = (billId) => {
    const bill = pendingBills.find(b => b.id === billId);
    if (!bill) return;
    setTransactions(prev => [{ id: Date.now(), type: 'expense', amount: bill.amount, category: 'utilities', description: `Paid bill: ${bill.name}`, date: new Date().toISOString() }, ...prev]);
    setBudget({ ...budget, spent: (budget.spent || 0) + bill.amount });
    setPendingBills(prev => prev.filter(b => b.id !== billId));
    showAlert('success', `Bill "${bill.name}" marked as paid`);
  };

  const resetData = () => {
    if (window.confirm('Reset all data? This cannot be undone.')) {
      setTransactions([]);
      setPendingBills([]);
      setBudget({ amount: 0, period: 'monthly', spent: 0, startDate: null, endDate: null, savings: 0 });
      showAlert('info', 'All data has been reset.');
    }
  };

  return (
    <div>
      <div className="page-title">
        <i className="fas fa-exchange-alt" style={{ color: 'var(--primary-color)', marginRight: 10 }} />
        {t.nav.transactions}
      </div>

      <div className="form-container">
        <h3>{t.transactions.addTransaction}</h3>
        <div className="form-group">
          <label>{t.transactions.type}</label>
          <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
            <option value="expense">{t.transactions.expense}</option>
            <option value="income">{t.transactions.income}</option>
          </select>
        </div>
        <div className="form-group">
          <label>{t.transactions.amount}</label>
          <input type="number" placeholder="Enter amount" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="form-group">
          <label>{t.transactions.category}</label>
          <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
            {CATEGORIES.map(cat => <option key={cat} value={cat}>{t.transactions[cat] || cat}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label>{t.transactions.description}</label>
          <input type="text" placeholder="Enter description" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
        </div>

        {/* Voice section */}
        <div style={{ margin: '16px 0', padding: 14, background: 'var(--background-color)', borderRadius: 8, border: '1px solid var(--border-color)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
            <button
              onClick={isListening ? stopVoice : startVoice}
              style={{
                background: isListening ? '#ff0000' : 'var(--primary-color)',
                color: 'white', border: 'none', borderRadius: 6,
                padding: '8px 16px', cursor: 'pointer', fontWeight: 600,
                display: 'flex', alignItems: 'center', gap: 8,
                animation: isListening ? 'pulse 1.5s infinite' : 'none',
                fontFamily: 'inherit',
              }}
            >
              <i className={`fas fa-microphone${isListening ? '-slash' : ''}`} />
              {isListening ? 'Stop Listening' : 'Voice Input'}
            </button>
            {voiceTranscript && (
              <span style={{ fontSize: 13, color: 'var(--text-secondary)', fontStyle: 'italic' }}>{voiceTranscript}</span>
            )}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
            <i className="fas fa-lightbulb" style={{ color: '#ffd700', marginRight: 6 }} />
            Say: <strong>"add expense 500 for food"</strong> &nbsp;|&nbsp; <strong>"add income 2000 for salary"</strong> &nbsp;|&nbsp; <strong>"transport 150"</strong>
          </div>
        </div>

        <button className="btn-primary" onClick={() => addTransaction()}>
          <i className="fas fa-plus" /> {t.transactions.addTransactionBtn}
        </button>
        <button className="btn-danger" onClick={resetData}>
          <i className="fas fa-redo" /> {t.transactions.reset}
        </button>
      </div>

      {/* Transactions List */}
      <div className="transactions-list">
        <h3>{t.transactions.recentTransactions}</h3>
        {transactions.length === 0 ? (
          <div className="empty-state"><i className="fas fa-receipt" /><p>No transactions yet. Add your first one!</p></div>
        ) : (
          transactions.map(tx => (
            <div key={tx.id} className="transaction-item">
              <div className="transaction-info">
                <span className="transaction-description">{tx.description}</span>
                <span className="transaction-meta">
                  <span style={{ textTransform: 'capitalize' }}>{tx.category}</span>
                  <span>•</span>
                  <span>{new Date(tx.date).toLocaleDateString()}</span>
                </span>
              </div>
              <span className={`transaction-amount ${tx.type}`}>
                {tx.type === 'expense' ? '-' : '+'}₹{tx.amount.toFixed(2)}
              </span>
            </div>
          ))
        )}
      </div>

      {/* Pending Bills */}
      <div className="pending-bills-section">
        <h3>{t.transactions.pendingBills}</h3>
        <div className="form-group">
          <label>{t.transactions.billName}</label>
          <input type="text" placeholder="Enter bill name" value={billForm.name} onChange={e => setBillForm(f => ({ ...f, name: e.target.value }))} />
        </div>
        <div className="form-group">
          <label>{t.transactions.billAmount}</label>
          <input type="number" placeholder="Enter bill amount" value={billForm.amount} onChange={e => setBillForm(f => ({ ...f, amount: e.target.value }))} />
        </div>
        <div className="form-group">
          <label>{t.transactions.dueDate}</label>
          <input type="date" value={billForm.dueDate} onChange={e => setBillForm(f => ({ ...f, dueDate: e.target.value }))} />
        </div>
        <button className="btn-primary" onClick={addBill}>
          <i className="fas fa-plus" /> {t.transactions.addBill}
        </button>
        <div style={{ marginTop: 20 }}>
          {pendingBills.length === 0 ? (
            <div className="empty-state" style={{ padding: '20px 0' }}><p>No pending bills</p></div>
          ) : (
            pendingBills.map(bill => {
              const daysRemaining = Math.ceil((new Date(bill.dueDate) - new Date()) / (1000 * 60 * 60 * 24));
              return (
                <div key={bill.id} className="bill-item">
                  <div className="bill-details">
                    <h4>{bill.name}</h4>
                    <p>Amount: ₹{bill.amount}</p>
                    <p>Due: {new Date(bill.dueDate).toLocaleDateString()}</p>
                    <p className="days-remaining">{t.common.daysRemaining}: {daysRemaining}</p>
                  </div>
                  <button className="bill-paid-btn" onClick={() => markBillAsPaid(bill.id)}>
                    <i className="fas fa-check" /> {t.transactions.markPaid}
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

export default Transactions;
