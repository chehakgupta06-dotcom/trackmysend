import React, { useEffect, useRef } from 'react';

function FallingCoins() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animId;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const COIN_COUNT = 28;

    function createCoin(fromTop) {
      const size = 10 + Math.random() * 18;
      return {
        x: Math.random() * canvas.width,
        y: fromTop ? -size * 2 : Math.random() * canvas.height,
        size,
        speed: 0.6 + Math.random() * 1.4,
        swing: Math.random() * 1.5 - 0.75,
        swingSpeed: 0.01 + Math.random() * 0.02,
        swingAngle: Math.random() * Math.PI * 2,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.06,
        opacity: 0.15 + Math.random() * 0.35,
        scalePhase: Math.random() * Math.PI * 2,
      };
    }

    const coins = Array.from({ length: COIN_COUNT }, () => createCoin(false));

    function drawCoin(c) {
      ctx.save();
      ctx.globalAlpha = c.opacity;
      ctx.translate(c.x, c.y);
      ctx.rotate(c.rotation);
      const sx = Math.abs(Math.cos(c.scalePhase));
      ctx.scale(sx, 1);

      const grad = ctx.createRadialGradient(-c.size * 0.2, -c.size * 0.2, c.size * 0.05, 0, 0, c.size);
      grad.addColorStop(0, '#ffe066');
      grad.addColorStop(0.5, '#e5a800');
      grad.addColorStop(1, '#b8860b');

      ctx.beginPath();
      ctx.arc(0, 0, c.size, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();
      ctx.strokeStyle = 'rgba(255,240,120,0.6)';
      ctx.lineWidth = c.size * 0.12;
      ctx.stroke();

      if (sx > 0.3) {
        ctx.fillStyle = 'rgba(120,70,0,0.75)';
        ctx.font = `bold ${c.size * 0.9}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('₹', 0, 0);
      }
      ctx.restore();
    }

    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      coins.forEach(c => {
        drawCoin(c);
        c.y += c.speed;
        c.swingAngle += c.swingSpeed;
        c.x += Math.sin(c.swingAngle) * c.swing;
        c.rotation += c.rotSpeed;
        c.scalePhase += 0.04;
        if (c.y > canvas.height + c.size * 2) {
          Object.assign(c, createCoin(true));
        }
      });
      animId = requestAnimationFrame(animate);
    }

    animate();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute', top: 0, left: 0,
        width: '100%', height: '100%',
        pointerEvents: 'none', zIndex: 0, borderRadius: 8,
      }}
    />
  );
}

function Dashboard({ budget, t }) {
  const spent = budget.spent || 0;
  const total = budget.amount || 0;
  const remaining = total - spent;
  const savings = budget.savings || 0;
  const percent = total > 0 ? Math.min((spent / total) * 100, 100) : 0;
  const progressColor = percent >= 80 ? '#ff0000' : percent >= 50 ? '#ffa500' : '#4caf50';

  return (
    <div>
      <div style={{
        position: 'relative',
        background: 'linear-gradient(135deg, #1a0000 0%, #2d0000 50%, #141414 100%)',
        borderRadius: 10,
        overflow: 'hidden',
        marginBottom: 30,
        minHeight: 170,
        display: 'flex',
        alignItems: 'center',
        padding: '28px 32px',
        border: '1px solid #3a0000',
      }}>
        <FallingCoins />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: 44,
            color: '#e50914',
            letterSpacing: 2,
            lineHeight: 1,
            textShadow: '0 0 30px rgba(229,9,20,0.5)',
          }}>
            TrackMySpend
          </div>
          <div style={{ color: '#b3b3b3', marginTop: 8, fontSize: 15 }}>
            Smart budget tracker — stay in control of every rupee
          </div>
          {budget.startDate && (
            <div style={{
              marginTop: 10,
              display: 'inline-block',
              background: 'rgba(229,9,20,0.15)',
              border: '1px solid rgba(229,9,20,0.4)',
              borderRadius: 4,
              padding: '4px 12px',
              fontSize: 12,
              color: '#e50914',
              fontWeight: 600,
              letterSpacing: 0.5,
            }}>
              {(budget.period || 'monthly').toUpperCase()} BUDGET &nbsp;·&nbsp;
              {new Date(budget.startDate).toLocaleDateString()} → {new Date(budget.endDate).toLocaleDateString()}
            </div>
          )}
        </div>
      </div>

      <div className="cards">
        <div className="card">
          <h3>{t.dashboard.totalBudget}</h3>
          <div className="amount">₹{total.toFixed(2)}</div>
        </div>
        <div className="card">
          <h3>{t.dashboard.amountSpent}</h3>
          <div className="amount" style={{ color: 'var(--primary-color)' }}>₹{spent.toFixed(2)}</div>
        </div>
        <div className="card">
          <h3>{t.dashboard.remainingBudget}</h3>
          <div className="amount" style={{ color: remaining < 0 ? 'var(--primary-color)' : '#4caf50' }}>
            ₹{remaining.toFixed(2)}
          </div>
        </div>
        <div className="card savings">
          <h3>{t.dashboard.savings}</h3>
          <div className="amount" style={{ color: '#4caf50' }}>₹{savings.toFixed(2)}</div>
        </div>
      </div>

      <div className="progress-container">
        <h3>{t.dashboard.budgetProgress}</h3>
        <div className="progress-bar">
          <div className="progress" style={{ width: `${percent}%`, backgroundColor: progressColor }} />
        </div>
        {total > 0 ? (
          <p className="progress-text" style={{ color: percent >= 80 ? '#ff0000' : undefined, fontWeight: percent >= 80 ? 600 : 'normal' }}>
            ₹{spent.toFixed(2)} spent of ₹{total.toFixed(2)} ({Math.round(percent)}%)
          </p>
        ) : (
          <p className="progress-text">No budget set — go to Budget tab to get started</p>
        )}
      </div>

      <div className="app-links">
        <h3>{t.dashboard.tryWebApp}</h3>
        <div className="buttons">
          <button className="btn-app"><i className="fas fa-wallet" /> Try the WEB APP</button>
          <button className="btn-app"><i className="fab fa-google-play" /> GET IT ON Google Play</button>
          <button className="btn-app"><i className="fab fa-apple" /> Download on the App Store</button>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
