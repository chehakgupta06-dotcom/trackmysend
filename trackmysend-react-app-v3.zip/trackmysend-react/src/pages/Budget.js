import React, { useState } from 'react';
import { useAlert } from '../AlertContext';

function Budget({ budget, setBudget, t }) {
  const { showAlert } = useAlert();
  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysLater = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [form, setForm] = useState({
    amount: budget.amount || '',
    period: budget.period || 'monthly',
    startDate: budget.startDate || today,
    endDate: budget.endDate || thirtyDaysLater,
  });

  const handleSubmit = () => {
    if (!form.amount || !form.startDate || !form.endDate) {
      showAlert('warning', 'Please fill in all fields');
      return;
    }
    if (new Date(form.endDate) <= new Date(form.startDate)) {
      showAlert('warning', 'End date must be after start date');
      return;
    }

    const newBudget = {
      ...budget,
      amount: parseFloat(form.amount),
      period: form.period,
      startDate: form.startDate,
      endDate: form.endDate,
      spent: 0,
    };
    setBudget(newBudget);
    showAlert('success', 'Budget has been set successfully!');
  };

  return (
    <div>
      <div className="page-title">
        <i className="fas fa-wallet" style={{ color: 'var(--primary-color)', marginRight: 10 }} />
        {t.nav.budget}
      </div>
      <div className="form-container">
        <h3>{t.budget.setBudget}</h3>

        <div className="form-group">
          <label>{t.budget.budgetAmount}</label>
          <input
            type="number"
            placeholder="Enter your budget amount"
            value={form.amount}
            onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
          />
        </div>

        <div className="form-group">
          <label>{t.budget.startDate}</label>
          <input
            type="date"
            value={form.startDate}
            onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))}
          />
        </div>

        <div className="form-group">
          <label>{t.budget.endDate}</label>
          <input
            type="date"
            value={form.endDate}
            onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))}
          />
        </div>

        <div className="form-group">
          <label>{t.budget.budgetPeriod}</label>
          <select
            value={form.period}
            onChange={e => setForm(f => ({ ...f, period: e.target.value }))}
          >
            <option value="monthly">{t.budget.monthly}</option>
            <option value="weekly">{t.budget.weekly}</option>
            <option value="yearly">{t.budget.yearly}</option>
          </select>
        </div>

        <button className="btn-primary" onClick={handleSubmit}>
          <i className="fas fa-check" /> {t.budget.setBudgetBtn}
        </button>
      </div>
    </div>
  );
}

export default Budget;
