import React, { useEffect, useRef } from 'react';

/* Animated coin background using canvas (replaces the video) */
function CoinBackground() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animId;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const COIN_COUNT = 55;

    function createCoin(fromTop) {
      const size = 14 + Math.random() * 30;
      return {
        x: Math.random() * canvas.width,
        y: fromTop ? -size * 2 : Math.random() * canvas.height,
        size,
        speed: 0.4 + Math.random() * 1.2,
        swing: Math.random() * 2 - 1,
        swingSpeed: 0.008 + Math.random() * 0.015,
        swingAngle: Math.random() * Math.PI * 2,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.05,
        opacity: 0.4 + Math.random() * 0.5,
        scalePhase: Math.random() * Math.PI * 2,
        // Random coin colours: gold, silver, copper
        colorType: Math.floor(Math.random() * 3),
      };
    }

    const coins = Array.from({ length: COIN_COUNT }, () => createCoin(false));

    const COLORS = [
      // Gold
      { c0: '#fff0a0', c1: '#d4a000', c2: '#8a6000', text: 'rgba(100,60,0,0.8)' },
      // Silver
      { c0: '#ffffff', c1: '#aaaaaa', c2: '#555555', text: 'rgba(60,60,60,0.7)' },
      // Copper
      { c0: '#ffcc99', c1: '#b05020', c2: '#6b2f0e', text: 'rgba(80,30,0,0.7)' },
    ];

    function drawCoin(c) {
      const col = COLORS[c.colorType];
      ctx.save();
      ctx.globalAlpha = c.opacity;
      ctx.translate(c.x, c.y);
      ctx.rotate(c.rotation);
      const sx = Math.abs(Math.cos(c.scalePhase));
      ctx.scale(sx, 1);

      const grad = ctx.createRadialGradient(-c.size * 0.25, -c.size * 0.25, c.size * 0.04, 0, 0, c.size);
      grad.addColorStop(0, col.c0);
      grad.addColorStop(0.55, col.c1);
      grad.addColorStop(1, col.c2);

      ctx.beginPath();
      ctx.arc(0, 0, c.size, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();

      // Rim
      ctx.strokeStyle = col.c0;
      ctx.lineWidth = c.size * 0.1;
      ctx.globalAlpha = c.opacity * 0.6;
      ctx.stroke();

      // Symbol
      if (sx > 0.25) {
        ctx.globalAlpha = c.opacity;
        ctx.fillStyle = col.text;
        ctx.font = `bold ${c.size * 0.85}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('₹', 0, 0);
      }
      ctx.restore();
    }

    function animate() {
      // Draw piled-coins background feel with a warm overlay
      ctx.fillStyle = '#4a3010';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Paint a radial glow in centre
      const radGrad = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, canvas.width * 0.7
      );
      radGrad.addColorStop(0, 'rgba(160,100,20,0.55)');
      radGrad.addColorStop(1, 'rgba(30,15,0,0.85)');
      ctx.fillStyle = radGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      coins.forEach(c => {
        drawCoin(c);
        c.y += c.speed;
        c.swingAngle += c.swingSpeed;
        c.x += Math.sin(c.swingAngle) * c.swing;
        c.rotation += c.rotSpeed;
        c.scalePhase += 0.035;
        if (c.y > canvas.height + c.size * 2) {
          Object.assign(c, createCoin(true));
        }
      });

      animId = requestAnimationFrame(animate);
    }

    animate();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'fixed',
        top: 0, left: 0,
        width: '100%', height: '100%',
        zIndex: 0,
        pointerEvents: 'none',
      }}
    />
  );
}

/* ── About Us Page ── */
function AboutUs({ onNavigateDashboard }) {
  const missionRef = useRef(null);

  const scrollToMission = (e) => {
    e.preventDefault();
    missionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const stats = [
    { icon: 'fa-lock',  label: '100% Secured Data' },
    { icon: 'fa-users', label: '1 Million+ Users' },
    { icon: 'fa-star',  label: '100K+ 5-star Reviews' },
    { icon: 'fa-award', label: 'App of the Day' },
  ];

  const features = [
    {
      icon: 'fa-chart-pie',
      title: 'Track My Spend',
      desc: 'Bank & account aggregation in Asia.',
      color: '#e50914',
    },
    {
      icon: 'fa-wallet',
      title: 'Money Tracker',
      desc: '#1 personal finance app on all platforms.',
      color: '#c0a000',
    },
    {
      icon: 'fa-brain',
      title: 'Smart Finance, Simplified',
      desc: 'Automate, Track & Grow Your Budget',
      color: '#2196f3',
    },
  ];

  return (
    <div style={{ position: 'relative', minHeight: '100vh', fontFamily: "'Inter', sans-serif" }}>
      {/* Animated coin canvas background */}
      <CoinBackground />

      {/* Dark overlay */}
      <div style={{
        position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
        background: 'rgba(0,0,0,0.42)', zIndex: 1, pointerEvents: 'none',
      }} />

      {/* Go to Dashboard button */}
      <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 1000 }}>
        <button
          onClick={onNavigateDashboard}
          style={{
            background: '#e50914', color: 'white',
            border: 'none', borderRadius: 6,
            padding: '10px 22px', fontSize: 14,
            fontWeight: 700, cursor: 'pointer',
            fontFamily: 'inherit',
            boxShadow: '0 4px 12px rgba(229,9,20,0.5)',
            transition: 'all 0.3s',
          }}
          onMouseEnter={e => { e.target.style.background = '#b20710'; e.target.style.transform = 'scale(1.05)'; }}
          onMouseLeave={e => { e.target.style.background = '#e50914'; e.target.style.transform = 'scale(1)'; }}
        >
          Go to Dashboard
        </button>
      </div>

      {/* ── HERO SECTION ── */}
      <section style={{
        position: 'relative', zIndex: 2,
        height: '100vh',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        textAlign: 'center', padding: '0 20px',
      }}>
        <div>
          <h1 style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: 'clamp(2.5rem, 8vw, 5.5rem)',
            fontWeight: 400,
            background: 'linear-gradient(90deg, #FFD700, #C0C0C0)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            letterSpacing: 2,
            lineHeight: 1.1,
            textShadow: 'none',
            marginBottom: 20,
          }}>
            We Are TRACKMYSPEND
          </h1>
          <p style={{
            fontSize: 'clamp(1rem, 2.5vw, 1.25rem)',
            color: 'rgba(255,255,255,0.9)',
            marginBottom: 36,
            maxWidth: 600,
            lineHeight: 1.7,
          }}>
            We believe in a world where people don't have to worry about managing finances
          </p>
          <button
            onClick={scrollToMission}
            style={{
              background: '#e50914', color: 'white',
              border: 'none', borderRadius: 6,
              padding: '14px 36px', fontSize: 16,
              fontWeight: 700, cursor: 'pointer',
              fontFamily: 'inherit',
              transition: 'background 0.3s',
              boxShadow: '0 6px 20px rgba(229,9,20,0.6)',
            }}
            onMouseEnter={e => e.target.style.background = '#b20710'}
            onMouseLeave={e => e.target.style.background = '#e50914'}
          >
            Join Us
          </button>
        </div>
      </section>

      {/* ── MISSION + STATS ── */}
      <section
        ref={missionRef}
        style={{
          position: 'relative', zIndex: 2,
          padding: '60px 20px',
          textAlign: 'center',
        }}
      >
        <div style={{ maxWidth: 900, margin: '0 auto' }}>
          <h2 style={{ fontSize: 'clamp(1.6rem, 4vw, 2.4rem)', fontWeight: 700, color: '#ffffff', marginBottom: 16 }}>
            Our Mission
          </h2>
          <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.8)', maxWidth: 700, margin: '0 auto 40px', lineHeight: 1.8 }}>
            Our mission is to provide innovative financial data aggregation and money management services to simplify personal and business finance.
          </p>

          {/* Stats bar */}
          <div style={{
            display: 'flex', justifyContent: 'space-around', flexWrap: 'wrap',
            gap: 20, padding: '28px 32px',
            background: 'rgba(240,240,240,0.88)',
            borderRadius: 12,
            marginBottom: 48,
            backdropFilter: 'blur(6px)',
          }}>
            {stats.map(s => (
              <div key={s.label} style={{ textAlign: 'center', flex: '1 1 140px', color: '#333' }}>
                <i className={`fas ${s.icon}`} style={{ fontSize: 36, color: '#333', marginBottom: 10, display: 'block' }} />
                <span style={{ fontSize: 15, fontWeight: 500 }}>{s.label}</span>
              </div>
            ))}
          </div>

          {/* Feature cards */}
          <div style={{ display: 'flex', justifyContent: 'center', gap: 24, flexWrap: 'wrap' }}>
            {features.map(f => (
              <div
                key={f.title}
                style={{
                  flex: '1 1 240px', maxWidth: 300,
                  padding: '30px 24px',
                  background: 'rgba(245,245,245,0.88)',
                  borderRadius: 10,
                  backdropFilter: 'blur(8px)',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                  transition: 'transform 0.3s, box-shadow 0.3s',
                  cursor: 'default',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'scale(1.05)';
                  e.currentTarget.style.boxShadow = '0 14px 36px rgba(0,0,0,0.35)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'scale(1)';
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(0,0,0,0.25)';
                }}
              >
                <i className={`fas ${f.icon}`} style={{ fontSize: 40, color: f.color, marginBottom: 16, display: 'block' }} />
                <h3 style={{ fontSize: 18, fontWeight: 700, color: '#222', marginBottom: 10 }}>{f.title}</h3>
                <p style={{ fontSize: 14, color: '#555', lineHeight: 1.6, margin: 0 }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{
        position: 'relative', zIndex: 2,
        background: 'rgba(10,10,10,0.95)',
        color: 'rgba(255,255,255,0.75)',
        textAlign: 'center',
        padding: '22px 20px',
        fontSize: 14,
        lineHeight: 1.9,
        marginTop: 20,
      }}>
        <p style={{ margin: 0 }}>© 2025 Track My Spend. All rights reserved.</p>
        <p style={{ margin: 0 }}>Address: VIT Chennai, Vandalur</p>
      </footer>
    </div>
  );
}

export default AboutUs;
