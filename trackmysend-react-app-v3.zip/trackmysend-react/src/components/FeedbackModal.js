import React, { useState } from 'react';
import { useAlert } from '../AlertContext';

// ─── CONFIGURE YOUR EMAILJS DETAILS HERE ───────────────────────────────────
const EMAILJS_PUBLIC_KEY  = 'sfEsyfn3fwvKKXaAm';   // from EmailJS → Account → Public Key
const EMAILJS_SERVICE_ID  = 'service_lxnti3n';       // from EmailJS → Email Services
const EMAILJS_TEMPLATE_ID = 'template_9gkt27u';      // from EmailJS → Email Templates
const TO_EMAIL            = 'chehakgupta06@gmail.com';
// ────────────────────────────────────────────────────────────────────────────

async function sendViaEmailJS({ name, email, rating, message }) {
  // Dynamically load EmailJS SDK if not already loaded
  if (!window.emailjs) {
    await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
    window.emailjs.init(EMAILJS_PUBLIC_KEY);
  }

  return window.emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
    to_email:  TO_EMAIL,
    from_name: name,
    from_email: email,
    reply_to:  email,
    rating:    `${rating}/5 stars`,
    message,
    subject:   `TrackMySpend Feedback from ${name}`,
  });
}

function FeedbackModal({ onClose, t }) {
  const { showAlert } = useAlert();
  const [form, setForm] = useState({ name: '', email: '', feedback: '' });
  const [rating, setRating] = useState(0);
  const [sending, setSending] = useState(false);

  const submit = async () => {
    if (!form.name || !form.email || !form.feedback) {
      showAlert('warning', 'Please fill in all fields');
      return;
    }
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      showAlert('warning', 'Please enter a valid email address');
      return;
    }

    setSending(true);

    // Always save locally first
    const feedbackData = { ...form, rating, timestamp: new Date().toISOString() };
    const stored = JSON.parse(localStorage.getItem('feedbacks') || '[]');
    stored.push(feedbackData);
    localStorage.setItem('feedbacks', JSON.stringify(stored));

    try {
      await sendViaEmailJS({ name: form.name, email: form.email, rating, message: form.feedback });
      showAlert('success', '✅ Feedback sent to your email successfully!');
      onClose();
    } catch (err) {
      console.error('EmailJS error:', err);
      // Give specific error hints
      let hint = 'Check your EmailJS Service ID, Template ID, and Public Key.';
      if (err && err.status === 400) hint = 'Template variables mismatch. Check your EmailJS template fields.';
      if (err && err.status === 401) hint = 'Invalid Public Key. Check EmailJS Account settings.';
      if (err && err.status === 422) hint = 'EmailJS service not found. Check your Service ID.';

      showAlert('warning', `Feedback saved locally but email failed. ${hint}`);
      onClose();
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="modal-close" onClick={onClose}>
          <i className="fas fa-times" />
        </button>
        <h2>Leave Feedback</h2>

        <div className="form-group">
          <label>{t.common.name}</label>
          <input
            type="text"
            placeholder="Your name"
            value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
          />
        </div>

        <div className="form-group">
          <label>{t.common.email}</label>
          <input
            type="email"
            placeholder="your@email.com"
            value={form.email}
            onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
          />
        </div>

        <div className="form-group">
          <label>{t.common.rating}</label>
          <div className="rating">
            {[1, 2, 3, 4, 5].map(star => (
              <i
                key={star}
                className={`fas fa-star ${star <= rating ? 'active' : ''}`}
                onClick={() => setRating(star)}
              />
            ))}
          </div>
        </div>

        <div className="form-group">
          <label>Feedback</label>
          <textarea
            rows={4}
            placeholder={t.common.feedbackPlaceholder}
            value={form.feedback}
            onChange={e => setForm(f => ({ ...f, feedback: e.target.value }))}
            style={{ resize: 'vertical' }}
          />
        </div>

        <button className="btn-primary" onClick={submit} disabled={sending}>
          {sending
            ? <><i className="fas fa-spinner fa-spin" /> Sending...</>
            : <><i className="fas fa-paper-plane" /> {t.common.submitFeedback}</>
          }
        </button>
      </div>
    </div>
  );
}

export default FeedbackModal;
