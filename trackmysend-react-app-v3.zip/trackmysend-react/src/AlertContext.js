import React, { createContext, useContext, useState, useCallback } from 'react';

const AlertContext = createContext(null);

export function AlertProvider({ children }) {
  const [alerts, setAlerts] = useState([]);

  const showAlert = useCallback((type, message) => {
    const id = Date.now() + Math.random();
    setAlerts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setAlerts(prev => prev.filter(a => a.id !== id));
    }, 5000);
  }, []);

  const dismissAlert = useCallback((id) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  }, []);

  return (
    <AlertContext.Provider value={{ showAlert }}>
      {children}
      <div className="alert-container">
        {alerts.map(alert => (
          <div key={alert.id} className={`alert ${alert.type}`}>
            <div className="alert-content">
              <i className={`fas ${
                alert.type === 'warning' ? 'fa-exclamation-triangle' :
                alert.type === 'success' ? 'fa-check-circle' :
                'fa-info-circle'
              }`} />
              <span>{alert.message}</span>
            </div>
            <button className="alert-close" onClick={() => dismissAlert(alert.id)}>
              <i className="fas fa-times" />
            </button>
          </div>
        ))}
      </div>
    </AlertContext.Provider>
  );
}

export function useAlert() {
  return useContext(AlertContext);
}
