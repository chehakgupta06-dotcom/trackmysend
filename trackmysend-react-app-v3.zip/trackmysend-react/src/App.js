import React, { useState, useEffect, useCallback } from 'react';
import { AlertProvider, useAlert } from './AlertContext';
import translations from './translations';
import Dashboard from './pages/Dashboard';
import Budget from './pages/Budget';
import Transactions from './pages/Transactions';
import Analytics from './pages/Analytics';
import FAQ from './pages/FAQ';
import AboutUs from './pages/AboutUs';
import FeedbackModal from './components/FeedbackModal';

function InnerApp() {
  const { showAlert } = useAlert();

  const [budget, setBudgetState] = useState(() => {
    try { return JSON.parse(localStorage.getItem('budget')) || { amount: 0, period: 'monthly', spent: 0, startDate: null, endDate: null, savings: 0 }; }
    catch { return { amount: 0, period: 'monthly', spent: 0, startDate: null, endDate: null, savings: 0 }; }
  });
  const [transactions, setTransactionsState] = useState(() => {
    try { return JSON.parse(localStorage.getItem('transactions')) || []; }
    catch { return []; }
  });
  const [pendingBills, setPendingBillsState] = useState(() => {
    try { return JSON.parse(localStorage.getItem('pendingBills')) || []; }
    catch { return []; }
  });

  const [page, setPage] = useState('dashboard');
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'dark');
  const [language, setLanguage] = useState(() => localStorage.getItem('language') || 'en');
  const [showFeedback, setShowFeedback] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const t = translations[language] || translations.en;

  const setBudget = useCallback((b) => {
    setBudgetState(b);
    localStorage.setItem('budget', JSON.stringify(b));
  }, []);

  const setTransactions = useCallback((fn) => {
    setTransactionsState(prev => {
      const next = typeof fn === 'function' ? fn(prev) : fn;
      localStorage.setItem('transactions', JSON.stringify(next));
      return next;
    });
  }, []);

  const setPendingBills = useCallback((fn) => {
    setPendingBillsState(prev => {
      const next = typeof fn === 'function' ? fn(prev) : fn;
      localStorage.setItem('pendingBills', JSON.stringify(next));
      return next;
    });
  }, []);

  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => { localStorage.setItem('language', language); }, [language]);

  useEffect(() => {
    if (!budget.amount || budget.amount === 0) return;
    const pct = (budget.spent / budget.amount) * 100;
    if (pct >= 100) showAlert('warning', 'You have exceeded your budget!');
    else if (pct >= 80) showAlert('warning', 'You have spent 80% of your budget!');
  }, [budget.spent]); // eslint-disable-line

  useEffect(() => {
    const today = new Date();
    pendingBills.forEach(bill => {
      const days = Math.ceil((new Date(bill.dueDate) - today) / (1000 * 60 * 60 * 24));
      if (days === 1) showAlert('warning', `Bill "${bill.name}" is due tomorrow! ₹${bill.amount}`);
    });
  }, []); // eslint-disable-line

  const navLinks = [
    { id: 'dashboard',    icon: 'fa-home',         label: t.nav.dashboard },
    { id: 'budget',       icon: 'fa-wallet',        label: t.nav.budget },
    { id: 'transactions', icon: 'fa-exchange-alt',  label: t.nav.transactions },
    { id: 'analytics',    icon: 'fa-chart-line',    label: t.nav.analytics },
    { id: 'faq',          icon: 'fa-question-circle', label: t.nav.faq },
    { id: 'aboutus',      icon: 'fa-info-circle',     label: t.nav.aboutUs },
  ];

  const navigate = (id) => { setPage(id); setMobileMenuOpen(false); };

  // Hide the main navbar and footer on About Us (it has its own full-screen layout)
  const isAboutUs = page === 'aboutus';

  return (
    <div data-theme={theme}>
      {isAboutUs ? (
        <AboutUs onNavigateDashboard={() => navigate('dashboard')} />
      ) : (
      <div className="container">
        <nav className="navbar">
          <div className="logo" onClick={() => navigate('dashboard')}>
            <i className="fas fa-film" /> TrackMySpend
          </div>

          <div className={`nav-links ${mobileMenuOpen ? 'open' : ''}`}>
            {navLinks.map(link => (
              <a key={link.id} className={page === link.id ? 'active' : ''} onClick={() => navigate(link.id)}>
                <i className={`fas ${link.icon}`} /> {link.label}
              </a>
            ))}
          </div>

          <div className="nav-right">
            <button className="theme-toggle" onClick={() => setTheme(th => th === 'dark' ? 'light' : 'dark')} title="Toggle theme">
              <i className={`fas fa-${theme === 'dark' ? 'sun' : 'moon'}`} />
            </button>
            <div className="language-selector">
              <label htmlFor="lang-select">Language:</label>
              <select id="lang-select" value={language} onChange={e => setLanguage(e.target.value)}>
                <option value="en">English</option>
                <option value="hi">Hindi</option>
                <option value="ta">Tamil</option>
                <option value="ja">Japanese</option>
              </select>
            </div>
          </div>
        </nav>

        {page === 'dashboard'    && <Dashboard budget={budget} t={t} />}
        {page === 'budget'       && <Budget budget={budget} setBudget={setBudget} t={t} />}
        {page === 'transactions' && (
          <Transactions
            transactions={transactions} setTransactions={setTransactions}
            budget={budget} setBudget={setBudget}
            pendingBills={pendingBills} setPendingBills={setPendingBills}
            t={t}
          />
        )}
        {page === 'analytics'    && <Analytics transactions={transactions} budget={budget} t={t} />}
        {page === 'faq'          && <FAQ />}

        <footer>
          <div className="feedback-section">
            <button className="btn-feedback" onClick={() => setShowFeedback(true)}>
              <i className="fas fa-comment-alt" style={{ marginRight: 6 }} />
              {t.common.leaveFeedback}
            </button>
          </div>
        </footer>

        {showFeedback && <FeedbackModal t={t} onClose={() => setShowFeedback(false)} />}
      </div>
      )}
    </div>
  );
}

function App() {
  return (
    <AlertProvider>
      <InnerApp />
    </AlertProvider>
  );
}

export default App;
